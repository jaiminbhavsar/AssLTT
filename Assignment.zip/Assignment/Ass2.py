# 2. Create a list of 10 cities and sort the list in ascending order.
# Print the elements in the list one by one.

shortedList = []
def finMinimum(lst):
    min = lst[0]
    for i in range(len(lst)):
        if (min > lst[i]):
            min = lst[i]
    shortedList.append(min)
    lst.remove(min)


if __name__== "__main__":
    listofCities = []
    for i in range(10):
        listofCities.append(input("Enter the city name:: "))
    print("Original List of Cities:: ",listofCities)
    for count in range(len(listofCities)):
        finMinimum(listofCities)
    print("Shorted List of Cities:: ", shortedList)
