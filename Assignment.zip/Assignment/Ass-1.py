# 1. Create a list of random numbers and sort the list in ascending order.
# Print the elements in the sorted list one by one.
# If a number in the sorted list is even, calculate and print its square.

import random
shortedList = []
def finMinimum(lst):
    min = lst[0]
    for i in range(len(lst)):
        if (min > lst[i]):
            min = lst[i]
    shortedList.append(min)
    lst.remove(min)


if __name__== "__main__":
    countOfNumbers = int(input("Enter the count of numbers want to generate: "))
    lowerRange = int(input("Enter the lowerRange of input for random number generation: "))
    upperRange = int(input("Enter the upperRange of input for random number generation: "))
    listRandomNumber = [random.randrange(lowerRange,upperRange,1) for i in range(countOfNumbers)]
    print("Random generated list:: ",listRandomNumber)
    for count in range(len(listRandomNumber)):
        finMinimum(listRandomNumber)
    print("Shorted List:: ", shortedList)
    for i in range(len(shortedList)):
        if(shortedList[i] % 2 == 0):
            shortedList[i] = shortedList[i] ** 2
    print("Shorted List with Square of even number:: ",shortedList)




