Prerequisites:
- Install Python and set environment variable
- Install Robot framework
- Install robot framework selenium Library
- Download chrome driver.exe and set the path for it. Place it in the Directory where Python is installed

-- Directory structure ---

Bin - contain Chrome Driver

resource - Directory contain 3 files 
1. configLabel.robot - It contains the configuration parameters(Test Data). Take all the Test Data parameters in this file only.
2. Keyword.robot - It contains different keywords utilised for the Different test cases.
3. locator.robot - It contains Web Element Locators. Declare all the locators in this file only. 

result -- Directory
1. contains the robot framework report

testsuite -- Directory
1. Create Different test script Here.

Execution Steps:      
1. Navigate to the project directory
2. Execute the below command:
robot -d result/ -i sampleSanityTest .\testSuite\sampleTest.robot

